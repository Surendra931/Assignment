function submitForm() {
    // Gather form data
    let firstName = document.getElementById("firstName").value;
    let lastName = document.getElementById("lastName").value;
    let dob = document.getElementById("dob").value;
    let country = document.getElementById("country").value;
    let gender = document.querySelector('input[name="gender"]:checked');
    let profession = document.getElementById("profession").value;
    let email = document.getElementById("email").value;
    let mobile = document.getElementById("mobile").value;

    // Validation
    if (!firstName || !lastName || !dob || !country || !gender || !profession || !email || !mobile) {
        alert("Please fill in all required fields.");
        return;
    }

    // Build popup content
    let popupContent = `
        <p><b>First Name:</b> ${firstName}</p>
        <p><b>Last Name:</b> ${lastName}</p>
        <p><b>Date of Birth:</b> ${dob}</p>
        <p><b>Country:</b> ${country}</p>
        <p><b>Gender:</b> ${gender.value}</p>
        <p><b>Profession:</b> ${profession}</p>
        <p><b>Email:</b> ${email}</p>
        <p><b>Mobile Number:</b> ${mobile}</p>
    `;

    // Display the modal
    document.getElementById("popupContent").innerHTML = popupContent;
    document.getElementById("myModal").style.display = "block";
}

function resetForm() {
    document.getElementById("surveyForm").reset();
}

function closeModal() {
    document.getElementById("myModal").style.display = "none";
}

// Close the modal when clicking outside of it
document.getElementById("myModal").addEventListener("click", function(event) {
    if (event.target === this) {
        closeModal();
    }
});

// Prevent the modal from closing when clicking inside it
document.querySelector(".modal-content").addEventListener("click", function(event) {
    event.stopPropagation();
});
