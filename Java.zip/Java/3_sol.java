import java.util.Scanner;
class PangramChecker {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String str = scanner.nextLine();
        boolean isPangram = pangramchecker(str);

        if (isPangram) {
            System.out.println("The input is a pangram.");
        } else {
            System.out.println("The input is not a pangram.");
        }
    }

    public static boolean pangramchecker(String sentense) {
        boolean[] alphabet = new boolean[26];
        sentense = sentense.toLowerCase();
        for (int i = 0; i < sentense.length(); i++) {
            char c = sentense.charAt(i);
            if ('a' <= c && c <= 'z')
                alphabet[c - 'a'] = true;
        }

        for (boolean letterPresent : alphabet) {
            if (!letterPresent) {
                return false;
            }
        }

        return true;
    }
}
