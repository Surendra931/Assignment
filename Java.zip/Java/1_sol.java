import java.util.Arrays;
import java.util.Collections;
import java.util.List;
class HelloWorld {
    public static void main(String[] args) {
        Integer a[]={1,2,3,4,5,6};
        List<Integer>arr=Arrays.asList(a);
        Collections.shuffle(arr);
        arr.toArray(a);
		System.out.println(Arrays.toString(a));
    }
}

/*

or else we can also shuffle it by swapping the elements randomly*/