var arr=[1,2,3,4,5];
var desc=arr.sort((a,b)=>b-a);
console.log(desc)