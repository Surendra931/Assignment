function rev(str)
{
  var words=str.split(' ');
 
  var reversedwords=words.map(function(word){
    return word.split("").reverse().join('');
  });
  var res=reversedwords.join(' ');
 
  return res;
}
var input="This is a Sunny Day";
var s=rev(input);
console.log(s)